import './heroloader.css'

const HeroLoader = ()=>{
return(

       <div className='spin2'></div>
)
}

export default HeroLoader