import "./NftDetails.css";
import Notifiaction from "./Notification/Notifiaction";
import { useParams } from "react-router-dom";
import { NFTData } from "../../assets/Data/Data";
import { Link } from "react-router-dom";
import { useState,useEffect } from "react";
import Successful from "./Modals/Successful";
import { domain } from "../../config";
import Loader from "../../components/loader/Loader";
import swal from "sweetalert";
function NftDetails() {
  const userDetails = JSON.parse(localStorage.getItem('user'))
  const { id } = useParams();
  const [nft,setNft] = useState(null)
  const [title,setTitle] = useState('')
  const [categoryNft,setCategoryNft] = useState(null)
  const [price,setPrice] = useState(0)
  useEffect(()=>{
    fetch(`${domain}/api/v1/nft/${id}`)
    .then(res=>res.json())
    .then(data=>{
      setNft(data)
      handleCatergory(data.data.category)
      convertEth(data.data.priceInEtherium)
    })
  },[])
  function handleCatergory(categories) {
    fetch(`${domain}/api/v1/nft?nftInMarket=true&sort=-priceInEtherium&category=${categories}`)
    .then(res=>res.json())
    .then(data=>{
      setCategoryNft(data)
    })
  }
  function convertEth(value){
    fetch('https://min-api.cryptocompare.com/data/price?fsym=ETH&tsyms=USD')
    .then(res=>res.json())
    .then(data=>{
     setPrice(data.USD*value)
    })
   }
   function turnOff(){
    setMod4(false)
   }
  const singleNft = NFTData.filter((item) => item.id === parseInt(2));
  const newSingleNft = Array.from(singleNft);
  const [Mod4, setMod4] = useState(false);
if(nft === null || categoryNft === null){
  return <Loader/>
}
  return (
    <>
        <div className="details-hold" key={nft.data.id}>
          <Notifiaction />
          <div className="nft-details">
            <div className="left">
              <img className="nft-image" crossOrigin="anonymous" src={domain + nft.data.photo} alt="nftImg" />
            </div>
            <div className="right">
              <p className="nft-name">{nft.data.name}</p>
              <span className="offer">Best Offer</span>
              <h4 className="price1">{nft.data.priceInEtherium}ETH</h4>
              <span className="price p-2">${price}</span>
              <p className="details">
                Explore a vibrant digital marketplace where creators and
                collectors come together to buy, sell, and trade unique NFTs.
              </p>
              <p className="creator">by {nft.data.nftOwner.username}</p>
              <button onClick={() => {
                fetch(`${domain}/api/v1/nft/buyNft/${nft.data.id}`,{
                  method:'POST',
                  headers:{
                    'Content-Type':'application/json',
                    'Authorization':`Bearer ${userDetails.token}`
                  }
                })
                .then(res=>res.json())
                .then(data=>{
                  console.log(data)
                  if(data.status === 'fail'){
                  swal('Opps!',data.message,'error')
                  }else{
                    setTitle(data.message)
                    setMod4(true)
                  }
                })
              }}>Buy Now</button>
            </div>
          </div>
          <div className="more">
            <h3>More on Collection</h3>
            <div className="more-cards">
              {categoryNft.data.map((item) => (
                <div className="nft__card" key={item.id}>
                  <div className="card-hold">
                    <div className="tops">
                      <Link to={`/MarketPlace/${item.id}`}>
                        <img className="bg" crossOrigin="anonymous" src={domain+item.photo} alt="nftImage" />
                      </Link>
                      <div className="glass">
                        <p>For Sale</p>
                      </div>
                    </div>
                    <div className="bottom">
                      <p>
                        <Link>{item.name}</Link>
                      </p>
                      <div className="profile">
                        <div className="left">
                          <img
                            className="pics"
                            crossOrigin="anonymous"
                            src={domain+item.nftOwner.photo}
                            alt="profileImg"
                          />
                          <div className="text">
                            <p>{item.nftOwner.username}</p>
                            <span>@{item.nftOwner.username}</span>
                          </div>
                        </div>
                        <div className="right">
                          <span>Current Bid</span>
                          <p>{item.priceInEtherium}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      {Mod4 && <Successful turnOff={turnOff} title={title} setMod4={setMod4} />}
    </>
  );
}

export default NftDetails;
